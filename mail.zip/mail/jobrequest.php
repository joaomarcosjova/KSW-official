<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // Adjust the path to autoload.php based on your project structure

// Function to sanitize form inputs
function sanitizeInput($input)
{
    return htmlspecialchars(trim($input));
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize form inputs
    $category = sanitizeInput($_POST["position"]);
    $fullName = sanitizeInput($_POST["fullName"]);
    $mail = sanitizeInput($_POST["mail"]);
    $cv = sanitizeInput($_POST["cv"]);

    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->SMTPDebug = SMTP::DEBUG_OFF;
        $mail->isSMTP();
        $mail->Host       = 'smtp.hostinger.com'; // Update with your SMTP host
        $mail->SMTPAuth   = true;
        $mail->Username   = 'info@kadoshsoftwares.com'; // Update with your SMTP username
        $mail->Password   = 'Cristinanatacha3@'; // Update with your SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Use 'tls' or 'ssl' based on your SMTP server
        $mail->Port       = 465; // Update with your SMTP port

        //Recipients
        $mail->setFrom('info@kadoshsoftwares.com', 'Kadosh Softwares'); // Update with your sender email and name
        $mail->addAddress('info@kadoshsoftwares.com', 'Kadosh Softwares'); // Update with your recipient email and name

        //Attachments
        $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
        // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'New Job Application';
        $mail->Body    = "
            <p><strong>Name:</strong> $fullName</p>
            <p><strong>Phone:</strong> $mail</p>
            <p><strong>Email:</strong> $companyEmail</p>
            <p><strong>Company:</strong> $position</p>
            <p><strong>Category:</strong> $cv</p>
        ";

        // Send the email
        $mail->send();

        // Redirect to a thank you page
        header("Location: thank_you.html");
        exit();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
